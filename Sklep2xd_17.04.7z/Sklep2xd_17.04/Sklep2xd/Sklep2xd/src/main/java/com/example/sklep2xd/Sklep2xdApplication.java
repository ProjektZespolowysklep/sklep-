package com.example.sklep2xd;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sklep2xdApplication {

	public static void main(String[] args) {
		SpringApplication.run(Sklep2xdApplication.class, args);
	}

}
